"use client";

import { useState, useCallback } from "react";
import { YouTubeVideo } from "@/types/project";

// ==============================================
// HOOK PENCARIAN VIDEO (dipakai di app/nachyntube/page.tsx)
// Manggil backend internal /nachyntube/api/search, BUKAN langsung ke
// YouTube API, supaya API key tetap aman di server.
// ==============================================

export function useSearch() {
  const [results, setResults] = useState<YouTubeVideo[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const search = useCallback(async (query: string) => {
    if (!query.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(
        `/nachyntube/api/search?q=${encodeURIComponent(query)}`
      );
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error ?? "Gagal mengambil hasil pencarian.");
      }
      const data = await res.json();
      setResults(data.results ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Terjadi kesalahan.");
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  return { results, loading, error, search };
}
