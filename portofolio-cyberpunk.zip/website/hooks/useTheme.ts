"use client";

import { useEffect, useState } from "react";

// ==============================================
// HOOK TEMA
// Website ini didesain dominan DARK MODE (sesuai brief), tapi hook ini
// disiapkan kalau suatu saat kamu mau nambah opsi light mode.
// Tema tersimpan di localStorage key "nachyn-theme".
// ==============================================

type Theme = "dark" | "light";

export function useTheme() {
  const [theme, setTheme] = useState<Theme>("dark");

  useEffect(() => {
    const saved = (typeof window !== "undefined" &&
      localStorage.getItem("nachyn-theme")) as Theme | null;
    if (saved) setTheme(saved);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    localStorage.setItem("nachyn-theme", theme);
  }, [theme]);

  const toggleTheme = () => setTheme((t) => (t === "dark" ? "light" : "dark"));

  return { theme, toggleTheme, setTheme };
}
