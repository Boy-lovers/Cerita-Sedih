import { profile, skills, projects } from "@/lib/data";
import { ChatMessage } from "@/types/project";

// ======================================================================
// HELPER AI - dipakai oleh app/ai/api/chat/route.ts
// Chatbot ini dibuat "grounded": dia hanya diberi tahu tentang data
// profil kamu di lib/data.ts, supaya jawabannya soal KAMU, bukan ngarang.
//
// GANTI DI SINI kalau mau ubah kepribadian/gaya jawab AI-nya.
// ======================================================================

const MODEL = "claude-sonnet-5"; // model default, boleh diganti ke model Claude lain

/** Bangun system prompt dari data portofolio supaya AI tahu harus jawab apa */
export function buildSystemPrompt(): string {
  const skillList = skills.map((s) => `- ${s.name} (${s.level}%)`).join("\n");
  const projectList = projects
    .map((p) => `- ${p.title}: ${p.description}`)
    .join("\n");

  return `Kamu adalah asisten AI yang bertugas menjelaskan tentang ${profile.name} kepada pengunjung website portofolio ini.
Jawab HANYA berdasarkan informasi berikut, dengan gaya ramah, singkat, dan jelas. Jawab dalam Bahasa Indonesia kecuali diminta bahasa lain.
Kalau ditanya hal di luar topik profil/portofolio ini, jawab dengan sopan bahwa kamu fokus membantu menjelaskan tentang ${profile.name}.

PROFIL:
Nama: ${profile.name}
Peran: ${profile.role}
Lokasi: ${profile.location}
Tagline: ${profile.tagline}
Bio: ${profile.bio}

SKILL:
${skillList}

PROJECT:
${projectList}

Jangan mengarang informasi yang tidak ada di atas. Kalau tidak tahu, katakan dengan jujur dan arahkan pengunjung untuk menghubungi lewat halaman /contact.`;
}

/** Panggil Anthropic Messages API dengan riwayat chat */
export async function askAI(messages: ChatMessage[]): Promise<string> {
  const apiKey = process.env.ANTHROPIC_API_KEY;

  if (!apiKey) {
    return "⚠️ ANTHROPIC_API_KEY belum di-set di file .env.local. Tambahkan API key kamu supaya chat AI ini bisa aktif.";
  }

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 600,
      system: buildSystemPrompt(),
      messages: messages.map((m) => ({ role: m.role, content: m.content })),
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Anthropic API error (${response.status}): ${errText}`);
  }

  const data = await response.json();
  const textBlock = data.content?.find((c: { type: string }) => c.type === "text");
  return textBlock?.text ?? "Maaf, aku tidak bisa menjawab sekarang. Coba lagi ya.";
}
