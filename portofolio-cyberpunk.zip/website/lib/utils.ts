// ==============================================
// UTILITY FUNCTIONS UMUM
// Tambahin helper function lain di sini kalau butuh.
// ==============================================

/** Gabungin className, otomatis buang falsy value. Contoh: cn("a", cond && "b") */
export function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

/** Format tanggal ISO YouTube (mis. 2024-05-01T00:00:00Z) jadi "1 Mei 2024" */
export function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString("id-ID", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  } catch {
    return iso;
  }
}

/** Format durasi ISO 8601 YouTube (PT#H#M#S) jadi "1:23:45" atau "3:45" */
export function formatDuration(iso: string): string {
  const match = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return "0:00";
  const h = parseInt(match[1] || "0", 10);
  const m = parseInt(match[2] || "0", 10);
  const s = parseInt(match[3] || "0", 10);
  const mm = h > 0 ? String(m).padStart(2, "0") : String(m);
  const ss = String(s).padStart(2, "0");
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

/** Potong teks panjang + tambah "..." */
export function truncate(text: string, max = 120): string {
  if (text.length <= max) return text;
  return text.slice(0, max).trim() + "...";
}

/** Delay kecil, kepake buat simulasi/throttle di client */
export function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
