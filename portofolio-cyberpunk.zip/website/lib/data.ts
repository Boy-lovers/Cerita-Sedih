import { Project, Skill, StatItem, SocialLink } from "@/types/project";

// ======================================================================
// ⚠️ INI FILE PALING PENTING BUAT DIGANTI ⚠️
// Semua teks profil, project, skill, dan statistik ada di sini.
// Isi sekarang cuma CONTOH / PLACEHOLDER, silakan diganti semua.
// ======================================================================

// ----------------------------------------------------------------------
// 1. PROFIL SINGKAT
// GANTI: nama, jabatan/role, deskripsi singkat, dan foto (public/avatar.png)
// ----------------------------------------------------------------------
export const profile = {
  name: "Nachyn", // <-- GANTI nama kamu
  role: "Full-Stack Developer & Digital Tinkerer", // <-- GANTI jabatan/peran kamu
  tagline:
    "Membangun website dan tools yang cepat, rapi, dan sedikit futuristik.", // <-- GANTI tagline singkat
  bio: `Halo! Aku seseorang yang suka ngoprek web, bikin tools kecil yang
mempermudah hidup, dan belajar hal baru tiap minggu. Portofolio ini dibuat
dengan Next.js, dan aku juga suka eksperimen sama AI serta API pihak ketiga
seperti YouTube. Ganti paragraf ini dengan cerita tentang diri kamu sendiri —
latar belakang, minat, atau apa yang lagi kamu pelajari sekarang.`, // <-- GANTI bio panjang
  location: "Indonesia", // <-- GANTI lokasi kamu
  email: "nama@email.com", // <-- GANTI email kamu
  avatar: "/avatar.png", // <-- GANTI file fotonya di public/avatar.png
};

// ----------------------------------------------------------------------
// 2. STATISTIK (ditampilkan di komponen Stats.tsx)
// GANTI angka dan labelnya sesuai pencapaian kamu
// ----------------------------------------------------------------------
export const stats: StatItem[] = [
  { label: "Proyek Selesai", value: "12+" },
  { label: "Tahun Pengalaman", value: "3+" },
  { label: "Teknologi Dikuasai", value: "15+" },
  { label: "Cangkir Kopi", value: "∞" },
];

// ----------------------------------------------------------------------
// 3. DAFTAR SKILL (ditampilkan di SkillCard.tsx pada halaman /portfolio)
// GANTI/TAMBAH/HAPUS sesuai kemampuan kamu. `level` = 0-100
// ----------------------------------------------------------------------
export const skills: Skill[] = [
  { name: "Next.js / React", level: 90, category: "frontend" },
  { name: "TypeScript", level: 85, category: "frontend" },
  { name: "Tailwind CSS", level: 88, category: "frontend" },
  { name: "Node.js", level: 80, category: "backend" },
  { name: "REST & API Integration", level: 82, category: "backend" },
  { name: "Git & GitHub", level: 85, category: "tools" },
  { name: "UI/UX Design", level: 70, category: "other" },
];

// ----------------------------------------------------------------------
// 4. DAFTAR PROJECT (ditampilkan di ProjectCard.tsx pada halaman /portfolio)
// GANTI: title, description, image (taruh file di public/projects/), tags, link, repo
// ----------------------------------------------------------------------
export const projects: Project[] = [
  {
    id: "proj-1",
    title: "NachynTube",
    description:
      "Aplikasi nonton video YouTube dengan tampilan bersih memakai YouTube Data API, terintegrasi di portofolio ini.",
    image: "/projects/placeholder-1.svg",
    tags: ["Next.js", "YouTube API", "TypeScript"],
    link: "/nachyntube",
    featured: true,
  },
  {
    id: "proj-2",
    title: "AI Portfolio Assistant",
    description:
      "Chatbot AI yang bisa menjawab pertanyaan seputar profil, skill, dan proyek pemilik portofolio secara real-time.",
    image: "/projects/placeholder-2.svg",
    tags: ["Anthropic API", "Next.js", "Edge Function"],
    link: "/ai",
    featured: true,
  },
  {
    id: "proj-3",
    title: "Nama Project Kamu",
    description:
      "GANTI dengan deskripsi project kamu. Ceritakan masalah apa yang diselesaikan dan teknologi yang dipakai.",
    image: "/projects/placeholder-3.svg",
    tags: ["Ganti", "Tag", "Disini"],
    link: "#",
    repo: "#",
  },
];

// ----------------------------------------------------------------------
// 5. SOSIAL MEDIA / LINK KONTAK
// GANTI dengan link asli kamu (dipakai di Footer.tsx & halaman /contact)
// ----------------------------------------------------------------------
export const socials: SocialLink[] = [
  { label: "GitHub", url: "https://github.com/username", icon: "github" },
  { label: "LinkedIn", url: "https://linkedin.com/in/username", icon: "linkedin" },
  { label: "Instagram", url: "https://instagram.com/username", icon: "instagram" },
  { label: "Email", url: "mailto:nama@email.com", icon: "mail" },
];
