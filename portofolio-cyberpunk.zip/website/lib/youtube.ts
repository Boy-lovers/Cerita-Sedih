import { YouTubeVideo } from "@/types/project";

// ======================================================================
// HELPER YOUTUBE DATA API v3 - dipakai oleh app/nachyntube/api/search/route.ts
//
// CATATAN JUJUR SOAL "TANPA IKLAN":
// YouTube Data API TIDAK punya cara resmi untuk menghilangkan iklan
// sepenuhnya — iklan diatur oleh YouTube di sisi pemutar video.
// Yang dilakukan NachynTube di sini:
//   1. Pakai domain embed "youtube-nocookie.com" (mode privasi lebih ketat,
//      tanpa cookie tracking, dan tanpa clutter rekomendasi/branding YouTube).
//   2. Pemutar custom (lihat components/VideoPlayer.tsx) tanpa elemen
//      UI bawaan YouTube di sekitarnya, jadi pengalaman nonton lebih bersih.
// Ini BUKAN ad-blocker. Kalau butuh 100% zero-ad, itu di luar cakupan
// yang bisa dijamin lewat API resmi YouTube.
// ======================================================================

const YT_API_BASE = "https://www.googleapis.com/youtube/v3";

export async function searchYouTube(query: string): Promise<YouTubeVideo[]> {
  const apiKey = process.env.YOUTUBE_API_KEY;

  if (!apiKey) {
    throw new Error(
      "YOUTUBE_API_KEY belum di-set di .env.local. Tambahkan API key dari Google Cloud Console."
    );
  }

  const url = new URL(`${YT_API_BASE}/search`);
  url.searchParams.set("part", "snippet");
  url.searchParams.set("q", query);
  url.searchParams.set("type", "video");
  url.searchParams.set("maxResults", "16");
  url.searchParams.set("safeSearch", "moderate");
  url.searchParams.set("key", apiKey);

  const res = await fetch(url.toString());

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`YouTube API error (${res.status}): ${errText}`);
  }

  const data = await res.json();

  return (data.items ?? []).map((item: {
    id: { videoId: string };
    snippet: {
      title: string;
      channelTitle: string;
      description: string;
      publishedAt: string;
      thumbnails: { high?: { url: string }; medium?: { url: string } };
    };
  }) => ({
    id: item.id.videoId,
    title: item.snippet.title,
    channelTitle: item.snippet.channelTitle,
    thumbnail:
      item.snippet.thumbnails.high?.url ?? item.snippet.thumbnails.medium?.url ?? "",
    publishedAt: item.snippet.publishedAt,
    description: item.snippet.description,
  }));
}

/** Bangun URL embed privacy-enhanced (youtube-nocookie.com) buat VideoPlayer.tsx */
export function getEmbedUrl(videoId: string): string {
  const params = new URLSearchParams({
    rel: "0", // jangan tampilin video "terkait" dari channel lain
    modestbranding: "1", // kurangi logo YouTube
    playsinline: "1",
  });
  return `https://www.youtube-nocookie.com/embed/${videoId}?${params.toString()}`;
}
