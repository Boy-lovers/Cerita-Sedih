import type { Metadata } from "next";
import { profile, socials } from "@/lib/data";
import ContactForm from "@/components/ContactForm";

export const metadata: Metadata = {
  title: `Kontak — ${profile.name}`,
};

// ==============================================
// HALAMAN KONTAK
// Info kontak & sosial diambil dari lib/data.ts.
// Form ada di components/ContactForm.tsx (default: buka aplikasi
// email lewat mailto). Kalau mau kirim ke backend/email service
// asli, tinggal ganti fungsi handleSubmit di komponen itu.
// ==============================================

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 pb-24 pt-32">
      <div className="mb-10 text-center">
        <p className="font-mono text-xs text-neon-cyan">// GET_IN_TOUCH</p>
        <h1 className="mt-2 font-display text-4xl font-bold">
          Mari <span className="text-gradient">Terhubung</span>
        </h1>
        <p className="mx-auto mt-3 max-w-lg text-sm text-muted">
          Punya pertanyaan, ide kolaborasi, atau cuma mau say hi? Kirim pesan
          lewat form di bawah atau lewat sosial media aku.
        </p>
      </div>

      <div className="mb-8 flex flex-wrap justify-center gap-3">
        {socials.map((s) => (
          <a
            key={s.label}
            href={s.url}
            target="_blank"
            rel="noopener noreferrer"
            className="glass rounded-full px-4 py-2 text-sm text-white transition-transform hover:scale-105"
          >
            {s.label}
          </a>
        ))}
      </div>

      <ContactForm email={profile.email} />
    </div>
  );
}
