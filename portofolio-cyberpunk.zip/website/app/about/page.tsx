import type { Metadata } from "next";
import Image from "next/image";
import { profile, skills } from "@/lib/data";

export const metadata: Metadata = {
  title: `Tentang — ${profile.name}`,
};

// ==============================================
// HALAMAN TENTANG SAYA
// Konten diambil dari lib/data.ts -> GANTI di sana.
// ==============================================

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 pb-24 pt-32">
      <div className="glass-strong flex flex-col items-center gap-8 rounded-2xl p-8 sm:flex-row sm:items-start">
        <div className="relative h-32 w-32 flex-shrink-0">
          <Image
            src={profile.avatar}
            alt={profile.name}
            fill
            sizes="128px"
            className="rounded-2xl border-2 border-neon-purple/40 object-cover"
          />
        </div>
        <div>
          <p className="font-mono text-xs text-neon-cyan">// WHOAMI</p>
          <h1 className="mt-2 font-display text-3xl font-bold">
            {profile.name}
          </h1>
          <p className="mt-1 text-sm text-neon-purple">{profile.role}</p>
          <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-muted">
            {profile.bio}
          </p>
          <p className="mt-4 text-xs text-muted/70">📍 {profile.location}</p>
        </div>
      </div>

      <div className="mt-12">
        <h2 className="mb-6 font-display text-2xl font-bold">
          Ringkasan <span className="text-gradient">Kemampuan</span>
        </h2>
        <div className="flex flex-wrap gap-2">
          {skills.map((skill) => (
            <span
              key={skill.name}
              className="rounded-full border border-neon-purple/25 px-4 py-2 text-sm text-white"
            >
              {skill.name}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
