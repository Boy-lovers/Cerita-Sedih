"use client";

// ==============================================
// HALAMAN ERROR GLOBAL
// GANTI teks pesan error di bawah kalau mau nada yang beda.
// ==============================================

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center gap-4 px-4 text-center">
      <div className="glass-strong rounded-2xl p-10">
        <p className="font-mono text-xs text-neon-pink">// SYSTEM_ERROR</p>
        <h1 className="mt-3 font-display text-3xl font-bold text-white">
          Ada yang <span className="text-gradient">error</span>
        </h1>
        <p className="mt-3 max-w-md text-sm text-muted">
          {error.message || "Terjadi kesalahan tak terduga. Coba muat ulang halaman."}
        </p>
        <button
          onClick={reset}
          className="mt-6 rounded-xl bg-gradient-to-r from-neon-purple to-neon-violet px-6 py-3 text-sm font-semibold text-white shadow-neon transition-transform hover:scale-105"
        >
          Coba Lagi
        </button>
      </div>
    </div>
  );
}
