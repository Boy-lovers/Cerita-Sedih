import type { Metadata } from "next";
import ProjectCard from "@/components/ProjectCard";
import SkillCard from "@/components/SkillCard";
import { projects, skills, profile } from "@/lib/data";

export const metadata: Metadata = {
  title: `Portofolio — ${profile.name}`,
};

// ==============================================
// HALAMAN PORTOFOLIO
// Menampilkan seluruh project & skill dari lib/data.ts.
// GANTI konten di lib/data.ts, bukan di sini.
// ==============================================

export default function PortfolioPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 pb-24 pt-32">
      <div className="mb-14 text-center">
        <p className="font-mono text-xs text-neon-cyan">// PORTFOLIO_ARCHIVE</p>
        <h1 className="mt-2 font-display text-4xl font-bold">
          Semua <span className="text-gradient">Proyek</span> & Kemampuan
        </h1>
        <p className="mx-auto mt-3 max-w-lg text-sm text-muted">
          Kumpulan project yang pernah aku kerjakan, plus skill teknis yang
          aku kuasai sepanjang perjalanan ini.
        </p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>

      <div className="mt-20">
        <h2 className="mb-8 text-center font-display text-2xl font-bold">
          Skill & <span className="text-gradient">Teknologi</span>
        </h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {skills.map((skill) => (
            <SkillCard key={skill.name} skill={skill} />
          ))}
        </div>
      </div>
    </div>
  );
}
