import Loading from "@/components/Loading";

// Loading global, otomatis dipakai Next.js saat halaman lagi dimuat.
export default function GlobalLoading() {
  return <Loading label="Menyiapkan halaman..." />;
}
