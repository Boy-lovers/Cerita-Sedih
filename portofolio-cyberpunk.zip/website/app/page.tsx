import Hero from "@/components/Hero";
import Stats from "@/components/Stats";
import ProjectCard from "@/components/ProjectCard";
import Link from "next/link";
import { projects } from "@/lib/data";

// ==============================================
// HALAMAN UTAMA (LANDING PAGE)
// Ubah urutan section atau tambah section baru di sini.
// Konten tiap section ada di lib/data.ts.
// ==============================================

export default function HomePage() {
  const featured = projects.filter((p) => p.featured);

  return (
    <>
      <Hero />
      <Stats />

      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="mb-10 flex items-end justify-between">
          <div>
            <p className="font-mono text-xs text-neon-cyan">// FEATURED_PROJECTS</p>
            <h2 className="mt-2 font-display text-3xl font-bold">
              Proyek <span className="text-gradient">Unggulan</span>
            </h2>
          </div>
          <Link href="/portfolio" className="text-sm font-medium text-neon-purple hover:underline">
            Lihat semua →
          </Link>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-2">
          {featured.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-16 text-center">
        <div className="glass-strong rounded-2xl p-10">
          <p className="font-mono text-xs text-neon-cyan">// LET&apos;S CONNECT</p>
          <h2 className="mt-2 font-display text-2xl font-bold sm:text-3xl">
            Punya ide project atau sekadar mau ngobrol?
          </h2>
          <Link
            href="/contact"
            className="mt-6 inline-block rounded-xl bg-gradient-to-r from-neon-purple to-neon-violet px-6 py-3 text-sm font-semibold text-white shadow-neon transition-transform hover:scale-105"
          >
            Hubungi Aku
          </Link>
        </div>
      </section>
    </>
  );
}
