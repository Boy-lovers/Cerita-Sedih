import Link from "next/link";

// ==============================================
// HALAMAN 404
// GANTI teks di bawah kalau mau nada yang beda.
// ==============================================

export default function NotFound() {
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center gap-4 px-4 text-center">
      <p className="font-display text-8xl font-bold text-gradient">404</p>
      <h1 className="font-display text-2xl font-bold text-white">
        Halaman tidak ditemukan
      </h1>
      <p className="max-w-md text-sm text-muted">
        Sepertinya kamu tersesat di ruang siber. Halaman yang kamu cari tidak
        ada atau sudah dipindahkan.
      </p>
      <Link
        href="/"
        className="mt-4 rounded-xl bg-gradient-to-r from-neon-purple to-neon-violet px-6 py-3 text-sm font-semibold text-white shadow-neon transition-transform hover:scale-105"
      >
        Kembali ke Beranda
      </Link>
    </div>
  );
}
