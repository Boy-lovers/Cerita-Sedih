import type { Metadata } from "next";
import AIChatBox from "@/components/AIChatBox";
import { profile } from "@/lib/data";

export const metadata: Metadata = {
  title: `AI Chat — ${profile.name}`,
};

// ==============================================
// HALAMAN AI CHAT
// Komponen utamanya ada di components/AIChatBox.tsx,
// yang manggil backend di app/ai/api/chat/route.ts.
// ==============================================

export default function AIPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 pb-24 pt-32">
      <div className="mb-8 text-center">
        <p className="font-mono text-xs text-neon-cyan">// AI_ASSISTANT</p>
        <h1 className="mt-2 font-display text-4xl font-bold">
          Tanya <span className="text-gradient">AI</span> Tentang Aku
        </h1>
        <p className="mx-auto mt-3 max-w-lg text-sm text-muted">
          Chatbot ini terhubung ke data profil {profile.name}. Tanyakan apa
          saja soal skill, project, atau latar belakang.
        </p>
      </div>

      <AIChatBox />
    </div>
  );
}
