import { NextRequest, NextResponse } from "next/server";
import { askAI } from "@/lib/ai";
import { ChatMessage } from "@/types/project";

// ==============================================
// BACKEND API AI CHAT
// Endpoint: POST /ai/api/chat
// Body: { messages: ChatMessage[] }
//
// API key Anthropic diambil dari .env.local (ANTHROPIC_API_KEY),
// TIDAK PERNAH dikirim ke browser. GANTI logika di lib/ai.ts kalau
// mau ubah model atau system prompt.
// ==============================================

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const messages = body.messages as ChatMessage[] | undefined;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json(
        { error: "Field 'messages' wajib diisi dan berupa array." },
        { status: 400 }
      );
    }

    const reply = await askAI(messages);
    return NextResponse.json({ reply });
  } catch (err) {
    console.error("[AI_CHAT_ERROR]", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Terjadi kesalahan pada server." },
      { status: 500 }
    );
  }
}
