import { NextRequest, NextResponse } from "next/server";
import { searchYouTube } from "@/lib/youtube";

// ==============================================
// BACKEND API SEARCH YOUTUBE
// Endpoint: GET /nachyntube/api/search?q=keyword
//
// API key YouTube diambil dari .env.local (YOUTUBE_API_KEY),
// TIDAK PERNAH dikirim ke browser.
// ==============================================

export async function GET(req: NextRequest) {
  const query = req.nextUrl.searchParams.get("q");

  if (!query || !query.trim()) {
    return NextResponse.json(
      { error: "Parameter 'q' (kata kunci pencarian) wajib diisi." },
      { status: 400 }
    );
  }

  try {
    const results = await searchYouTube(query);
    return NextResponse.json({ results });
  } catch (err) {
    console.error("[YOUTUBE_SEARCH_ERROR]", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Gagal mengambil data YouTube." },
      { status: 500 }
    );
  }
}
