"use client";

import { useState } from "react";
import TubeSearch from "@/components/TubeSearch";
import VideoCard from "@/components/VideoCard";
import VideoPlayer from "@/components/VideoPlayer";
import { useSearch } from "@/hooks/useSearch";
import { YouTubeVideo } from "@/types/project";

// ==============================================
// HALAMAN NACHYNTUBE
// Cari video YouTube (lewat backend /nachyntube/api/search) dan
// tonton pakai pemutar embed bersih (lihat lib/youtube.ts untuk
// catatan jujur soal batasan "tanpa iklan").
// ==============================================

export default function NachynTubePage() {
  const { results, loading, error, search } = useSearch();
  const [selected, setSelected] = useState<YouTubeVideo | null>(null);

  return (
    <div className="mx-auto max-w-6xl px-4 pb-24 pt-32">
      <div className="mb-10 text-center">
        <p className="font-mono text-xs text-neon-cyan">// NACHYNTUBE_STREAM</p>
        <h1 className="mt-2 font-display text-4xl font-bold">
          <span className="text-gradient">NachynTube</span>
        </h1>
        <p className="mx-auto mt-3 max-w-lg text-sm text-muted">
          Cari & tonton video YouTube langsung di sini dengan tampilan
          minim-gangguan, ditenagai YouTube Data API.
        </p>
      </div>

      <TubeSearch onSearch={search} loading={loading} />

      {error && (
        <p className="mx-auto mt-6 max-w-lg rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-center text-sm text-red-300">
          ⚠️ {error}
        </p>
      )}

      {selected && (
        <div className="mt-10">
          <VideoPlayer video={selected} />
        </div>
      )}

      {results.length > 0 && (
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {results.map((video) => (
            <VideoCard key={video.id} video={video} onSelect={setSelected} />
          ))}
        </div>
      )}

      {!loading && !error && results.length === 0 && (
        <p className="mt-16 text-center text-sm text-muted">
          Ketik sesuatu di kolom pencarian untuk mulai menonton. 🎬
        </p>
      )}
    </div>
  );
}
