import Loading from "@/components/Loading";

export default function NachynTubeLoading() {
  return <Loading label="Menyiapkan NachynTube..." />;
}
