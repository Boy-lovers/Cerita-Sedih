// ==============================================
// TYPE DEFINITIONS - PROJECT / SKILL / VIDEO
// Kalau nambah field baru di lib/data.ts, tambahin juga typenya di sini.
// ==============================================

export interface Project {
  id: string;
  title: string;
  description: string;
  image: string; // path ke /public/projects/xxx.png
  tags: string[];
  link?: string; // link demo/live
  repo?: string; // link github
  featured?: boolean;
}

export interface Skill {
  name: string;
  level: number; // 0 - 100, dipakai buat progress bar di SkillCard
  category: "frontend" | "backend" | "tools" | "other";
}

export interface StatItem {
  label: string;
  value: string;
}

export interface SocialLink {
  label: string;
  url: string;
  icon: string; // nama icon (lihat komponen yang pakai)
}

// Tipe pesan chat AI
export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

// Tipe hasil pencarian video YouTube (NachynTube)
export interface YouTubeVideo {
  id: string;
  title: string;
  channelTitle: string;
  thumbnail: string;
  publishedAt: string;
  description: string;
}
