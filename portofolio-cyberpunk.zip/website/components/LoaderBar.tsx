// ==============================================
// LOADER BAR ATAS
// Garis progress tipis ungu-neon di paling atas halaman.
// Dipakai di app/loading.tsx dan app/nachyntube/loading.tsx
// ==============================================

export default function LoaderBar() {
  return (
    <div className="fixed left-0 top-0 z-[100] h-1 w-full overflow-hidden bg-transparent">
      <div className="h-full w-1/3 animate-[loaderMove_1.1s_ease-in-out_infinite] bg-gradient-to-r from-neon-purple via-neon-pink to-neon-cyan" />
      <style>{`
        @keyframes loaderMove {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(300%); }
        }
      `}</style>
    </div>
  );
}
