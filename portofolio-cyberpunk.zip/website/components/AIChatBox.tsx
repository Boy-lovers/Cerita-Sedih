"use client";

import { useState, useRef, useEffect } from "react";
import { ChatMessage } from "@/types/project";
import { profile } from "@/lib/data";
import { cn } from "@/lib/utils";

// ==============================================
// CHAT BOX AI (dipakai di halaman /ai)
// Mengirim pesan ke app/ai/api/chat/route.ts, yang lalu
// memanggil Anthropic API lewat lib/ai.ts.
// GANTI pertanyaan contoh di `suggestions` sesuai isi profil kamu.
// ==============================================

const suggestions = [
  "Ceritakan tentang dirimu",
  "Apa saja skill yang kamu kuasai?",
  "Project apa yang paling kamu banggakan?",
  "Bagaimana cara menghubungimu?",
];

export default function AIChatBox() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: `Halo! Aku asisten AI di portofolio ${profile.name}. Tanya apa saja soal profil, skill, atau project — aku bantu jawab. 👋`,
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  async function sendMessage(text: string) {
    if (!text.trim() || loading) return;
    const nextMessages: ChatMessage[] = [...messages, { role: "user", content: text }];
    setMessages(nextMessages);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/ai/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages }),
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error ?? "Gagal mendapat jawaban dari AI.");

      setMessages((prev) => [...prev, { role: "assistant", content: data.reply }]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            err instanceof Error
              ? `⚠️ ${err.message}`
              : "⚠️ Terjadi kesalahan tak terduga.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="glass-strong flex h-[70vh] w-full flex-col rounded-2xl">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-neon-purple/15 px-5 py-4">
        <div className="h-2.5 w-2.5 animate-glow-pulse rounded-full bg-neon-cyan" />
        <p className="font-mono text-sm text-muted">
          AI-Assistant · tentang {profile.name}
        </p>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto px-5 py-6">
        {messages.map((m, i) => (
          <div
            key={i}
            className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}
          >
            <div
              className={cn(
                "max-w-[80%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm",
                m.role === "user"
                  ? "bg-gradient-to-r from-neon-purple to-neon-violet text-white"
                  : "glass text-white/90"
              )}
            >
              {m.content}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="glass flex gap-1 rounded-2xl px-4 py-3">
              <span className="typing-dot h-2 w-2 rounded-full bg-neon-purple" />
              <span className="typing-dot h-2 w-2 rounded-full bg-neon-purple" />
              <span className="typing-dot h-2 w-2 rounded-full bg-neon-purple" />
            </div>
          </div>
        )}
      </div>

      {/* Suggestions (tampil kalau baru mulai chat) */}
      {messages.length <= 1 && (
        <div className="flex flex-wrap gap-2 px-5 pb-3">
          {suggestions.map((s) => (
            <button
              key={s}
              onClick={() => sendMessage(s)}
              className="rounded-full border border-neon-purple/25 px-3 py-1.5 text-xs text-muted transition-colors hover:border-neon-purple hover:text-white"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          sendMessage(input);
        }}
        className="flex items-center gap-2 border-t border-neon-purple/15 p-4"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Tanya sesuatu tentang aku..."
          className="flex-1 rounded-xl bg-white/5 px-4 py-3 text-sm text-white placeholder:text-muted/60 focus:outline-none focus:ring-2 focus:ring-neon-purple/50"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="rounded-xl bg-gradient-to-r from-neon-purple to-neon-violet px-5 py-3 text-sm font-semibold text-white shadow-neon-sm transition-opacity disabled:opacity-40"
        >
          Kirim
        </button>
      </form>
    </div>
  );
}
