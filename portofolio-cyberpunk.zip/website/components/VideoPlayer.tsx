import { YouTubeVideo } from "@/types/project";
import { getEmbedUrl } from "@/lib/youtube";

// ==============================================
// PEMUTAR VIDEO (dipakai di /nachyntube ketika user pilih video)
// Pakai embed privacy-enhanced youtube-nocookie.com — bukan ad-blocker,
// lihat catatan lengkap di lib/youtube.ts.
// ==============================================

export default function VideoPlayer({ video }: { video: YouTubeVideo }) {
  return (
    <div className="glass-strong overflow-hidden rounded-2xl">
      <div className="aspect-video w-full bg-black">
        <iframe
          key={video.id}
          src={getEmbedUrl(video.id)}
          title={video.title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="h-full w-full"
        />
      </div>
      <div className="p-5">
        <h2 className="font-display text-lg font-semibold text-white">{video.title}</h2>
        <p className="mt-1 text-sm text-muted">{video.channelTitle}</p>
        <p className="mt-3 whitespace-pre-line text-sm text-muted/80">{video.description}</p>
      </div>
    </div>
  );
}
