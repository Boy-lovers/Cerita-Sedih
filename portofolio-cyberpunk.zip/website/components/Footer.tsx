import Link from "next/link";
import { profile, socials } from "@/lib/data";

// ==============================================
// FOOTER
// Otomatis ambil data dari lib/data.ts, ganti di sana kalau perlu.
// ==============================================

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative mt-24 border-t border-neon-purple/15 px-4 py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-6 text-center">
        <div>
          <p className="font-display text-lg font-bold">
            <span className="text-gradient">{profile.name}</span>
          </p>
          <p className="mt-1 text-sm text-muted">{profile.tagline}</p>
        </div>

        <div className="flex flex-wrap justify-center gap-4">
          {socials.map((s) => (
            <a
              key={s.label}
              href={s.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-muted transition-colors hover:text-neon-purple"
            >
              {s.label}
            </a>
          ))}
        </div>

        <nav className="flex flex-wrap justify-center gap-4 text-sm text-muted">
          <Link href="/portfolio" className="hover:text-white">Portofolio</Link>
          <Link href="/ai" className="hover:text-white">AI Chat</Link>
          <Link href="/nachyntube" className="hover:text-white">NachynTube</Link>
          <Link href="/contact" className="hover:text-white">Kontak</Link>
        </nav>

        <p className="text-xs text-muted/70">
          © {year} {profile.name}. Dibuat dengan Next.js & Tailwind CSS.
        </p>
      </div>
    </footer>
  );
}
