// ==============================================
// BACKGROUND ANIMASI (orb blur ungu + grid cyberpunk)
// Dipasang sekali di app/layout.tsx supaya muncul di semua halaman.
// GANTI warna/jumlah orb di sini kalau mau efeknya beda.
// ==============================================

export default function AnimatedBackground() {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-background bg-cyber-grid"
    >
      <div className="animate-orb absolute -left-32 -top-32 h-96 w-96 rounded-full bg-neon-purple/30 blur-[120px]" />
      <div className="animate-orb absolute right-[-10%] top-1/3 h-[28rem] w-[28rem] rounded-full bg-neon-pink/20 blur-[130px] [animation-delay:4s]" />
      <div className="animate-orb absolute bottom-[-10%] left-1/4 h-80 w-80 rounded-full bg-neon-cyan/15 blur-[110px] [animation-delay:8s]" />

      {/* Scan line halus turun dari atas ke bawah, khas cyberpunk */}
      <div className="animate-scan-line absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-neon-purple/10 to-transparent" />
    </div>
  );
}
