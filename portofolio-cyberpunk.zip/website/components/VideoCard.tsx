import Image from "next/image";
import { YouTubeVideo } from "@/types/project";
import { formatDate, truncate } from "@/lib/utils";

// ==============================================
// CARD VIDEO (grid hasil pencarian di /nachyntube)
// ==============================================

export default function VideoCard({
  video,
  onSelect,
}: {
  video: YouTubeVideo;
  onSelect: (video: YouTubeVideo) => void;
}) {
  return (
    <button
      onClick={() => onSelect(video)}
      className="border-neon glass group overflow-hidden rounded-xl text-left transition-all"
    >
      <div className="relative aspect-video w-full overflow-hidden bg-black/40">
        <Image
          src={video.thumbnail}
          alt={video.title}
          fill
          sizes="(max-width: 768px) 100vw, 25vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <span className="absolute bottom-2 right-2 rounded bg-black/70 px-1.5 py-0.5 font-mono text-[10px] text-white">
          ▶ Tonton
        </span>
      </div>
      <div className="p-3">
        <h3 className="line-clamp-2 text-sm font-semibold text-white">{video.title}</h3>
        <p className="mt-1 text-xs text-muted">{video.channelTitle}</p>
        <p className="mt-1 text-[11px] text-muted/70">{formatDate(video.publishedAt)}</p>
        <p className="mt-2 line-clamp-2 text-xs text-muted/80">
          {truncate(video.description, 90)}
        </p>
      </div>
    </button>
  );
}
