"use client";

import { useState, FormEvent } from "react";

// ==============================================
// SEARCH BAR NACHYNTUBE
// GANTI placeholder teks di bawah kalau mau beda.
// ==============================================

export default function TubeSearch({
  onSearch,
  loading,
}: {
  onSearch: (query: string) => void;
  loading: boolean;
}) {
  const [value, setValue] = useState("");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    onSearch(value);
  }

  return (
    <form onSubmit={handleSubmit} className="glass-strong mx-auto flex max-w-2xl gap-2 rounded-2xl p-2">
      <input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Cari video di NachynTube..."
        className="flex-1 rounded-xl bg-transparent px-4 py-3 text-sm text-white placeholder:text-muted/60 focus:outline-none"
      />
      <button
        type="submit"
        disabled={loading || !value.trim()}
        className="rounded-xl bg-gradient-to-r from-neon-purple to-neon-violet px-6 py-3 text-sm font-semibold text-white shadow-neon-sm transition-opacity disabled:opacity-40"
      >
        {loading ? "Mencari..." : "Cari"}
      </button>
    </form>
  );
}
