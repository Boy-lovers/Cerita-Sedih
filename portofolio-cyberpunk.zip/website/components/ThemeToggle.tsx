"use client";

import { useTheme } from "@/hooks/useTheme";

// ==============================================
// TOMBOL GANTI TEMA
// Web ini didesain dominan dark mode sesuai brief, tombol ini
// disiapkan untuk pengembangan light mode di masa depan.
// ==============================================

export default function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      aria-label="Ganti tema"
      title="Ganti tema"
      className="glass flex h-9 w-9 items-center justify-center rounded-full text-sm transition-transform hover:scale-105"
    >
      {theme === "dark" ? "🌙" : "☀️"}
    </button>
  );
}
