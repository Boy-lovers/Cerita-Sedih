import LoaderBar from "@/components/LoaderBar";

// ==============================================
// KOMPONEN LOADING (dipakai di dalam app/loading.tsx, dll)
// GANTI teks di bawah kalau mau pesan loading yang beda.
// ==============================================

export default function Loading({ label = "Memuat halaman..." }: { label?: string }) {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4">
      <LoaderBar />
      <div className="relative h-14 w-14">
        <div className="absolute inset-0 animate-spin rounded-full border-2 border-neon-purple/20 border-t-neon-purple" />
        <div className="absolute inset-2 animate-ping rounded-full bg-neon-purple/20" />
      </div>
      <p className="font-mono text-sm text-muted">{label}</p>
    </div>
  );
}
