import Image from "next/image";
import Link from "next/link";
import { Project } from "@/types/project";

// ==============================================
// CARD PROJECT (dipakai di halaman /portfolio)
// Struktur ambil dari lib/data.ts -> GANTI isi project di sana,
// bukan di file ini.
// ==============================================

export default function ProjectCard({ project }: { project: Project }) {
  return (
    <div className="scan-sweep border-neon glass group relative overflow-hidden rounded-2xl transition-all">
      <div className="relative h-44 w-full overflow-hidden">
        <Image
          src={project.image}
          alt={project.title}
          fill
          sizes="(max-width: 768px) 100vw, 33vw"
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      <div className="p-5">
        <h3 className="font-display text-lg font-semibold text-white">
          {project.title}
        </h3>
        <p className="mt-2 text-sm text-muted">{project.description}</p>

        <div className="mt-4 flex flex-wrap gap-2">
          {project.tags.map((tag) => (
            <span
              key={tag}
              className="rounded-full bg-neon-purple/10 px-3 py-1 text-xs font-mono text-neon-purple"
            >
              {tag}
            </span>
          ))}
        </div>

        <div className="mt-5 flex gap-4 text-sm">
          {project.link && (
            <Link
              href={project.link}
              className="font-medium text-neon-cyan hover:underline"
            >
              Lihat Demo →
            </Link>
          )}
          {project.repo && (
            <a
              href={project.repo}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-muted hover:text-white"
            >
              Source Code
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
