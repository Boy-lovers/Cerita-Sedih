"use client";

import { useState, FormEvent } from "react";

// ==============================================
// FORM KONTAK
// Default: submit akan buka aplikasi email (mailto) dengan isi form
// sudah terisi otomatis. Kalau mau kirim ke backend/email service
// asli (Resend, Nodemailer, dll), GANTI isi function handleSubmit.
// ==============================================

export default function ContactForm({ email }: { email: string }) {
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const subject = encodeURIComponent(`Pesan dari ${name || "pengunjung website"}`);
    const body = encodeURIComponent(message);
    window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
  }

  return (
    <form onSubmit={handleSubmit} className="glass-strong space-y-4 rounded-2xl p-8">
      <div>
        <label className="mb-1 block text-xs font-medium text-muted">Nama</label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nama kamu"
          required
          className="w-full rounded-xl bg-white/5 px-4 py-3 text-sm text-white placeholder:text-muted/60 focus:outline-none focus:ring-2 focus:ring-neon-purple/50"
        />
      </div>
      <div>
        <label className="mb-1 block text-xs font-medium text-muted">Pesan</label>
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Tulis pesan kamu di sini..."
          required
          rows={5}
          className="w-full rounded-xl bg-white/5 px-4 py-3 text-sm text-white placeholder:text-muted/60 focus:outline-none focus:ring-2 focus:ring-neon-purple/50"
        />
      </div>
      <button
        type="submit"
        className="w-full rounded-xl bg-gradient-to-r from-neon-purple to-neon-violet px-6 py-3 text-sm font-semibold text-white shadow-neon transition-transform hover:scale-105"
      >
        Kirim Pesan
      </button>
    </form>
  );
}
