import { Skill } from "@/types/project";

// ==============================================
// CARD SKILL DENGAN PROGRESS BAR (dipakai di halaman /portfolio)
// Data ambil dari lib/data.ts -> GANTI isi skill di sana.
// ==============================================

export default function SkillCard({ skill }: { skill: Skill }) {
  return (
    <div className="glass rounded-xl p-4">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-sm font-medium text-white">{skill.name}</span>
        <span className="font-mono text-xs text-neon-purple">{skill.level}%</span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-white/5">
        <div
          className="h-full rounded-full bg-gradient-to-r from-neon-purple to-neon-cyan shadow-neon-sm"
          style={{ width: `${skill.level}%` }}
        />
      </div>
    </div>
  );
}
