import { stats } from "@/lib/data";

// ==============================================
// STATISTIK (tampil di halaman utama)
// Data diambil dari lib/data.ts -> GANTI di sana.
// ==============================================

export default function Stats() {
  return (
    <section className="mx-auto max-w-5xl px-4 py-16">
      <div className="glass grid grid-cols-2 gap-6 rounded-2xl p-8 sm:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.label} className="text-center">
            <p className="font-display text-3xl font-bold text-gradient sm:text-4xl">
              {stat.value}
            </p>
            <p className="mt-2 text-xs text-muted sm:text-sm">{stat.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
