import Link from "next/link";
import Image from "next/image";
import { profile } from "@/lib/data";

// ==============================================
// HERO SECTION (tampil di halaman utama app/page.tsx)
// Konten diambil otomatis dari lib/data.ts -> GANTI di sana.
// ==============================================

export default function Hero() {
  return (
    <section className="relative flex min-h-screen flex-col items-center justify-center px-4 pt-24 text-center">
      <div className="animate-fade-up glass-strong mb-8 flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-mono text-neon-cyan">
        <span className="h-2 w-2 animate-glow-pulse rounded-full bg-neon-cyan" />
        SYSTEM ONLINE — WELCOME TO MY PORTFOLIO
      </div>

      <div className="animate-fade-up relative mb-6 h-32 w-32 [animation-delay:0.1s]">
        <div className="absolute inset-0 animate-glow-pulse rounded-full bg-neon-purple/40 blur-2xl" />
        <Image
          src={profile.avatar}
          alt={profile.name}
          fill
          sizes="128px"
          className="relative rounded-full border-2 border-neon-purple/50 object-cover shadow-neon"
        />
      </div>

      <h1 className="animate-fade-up font-display text-4xl font-bold tracking-tight sm:text-6xl [animation-delay:0.2s]">
        Halo, aku <span className="text-gradient">{profile.name}</span>
      </h1>
      <p className="animate-fade-up mt-4 max-w-xl text-lg text-muted [animation-delay:0.3s]">
        {profile.role}
      </p>
      <p className="animate-fade-up mt-2 max-w-xl text-sm text-muted/80 [animation-delay:0.35s]">
        {profile.tagline}
      </p>

      <div className="animate-fade-up mt-10 flex flex-wrap justify-center gap-4 [animation-delay:0.4s]">
        <Link
          href="/portfolio"
          className="rounded-xl bg-gradient-to-r from-neon-purple to-neon-violet px-6 py-3 text-sm font-semibold text-white shadow-neon transition-transform hover:scale-105"
        >
          Lihat Portofolio
        </Link>
        <Link
          href="/ai"
          className="glass rounded-xl px-6 py-3 text-sm font-semibold text-white transition-transform hover:scale-105"
        >
          Tanya AI Tentang Aku →
        </Link>
      </div>
    </section>
  );
}
